<?php

//Default days to be banned
//Currently is counted by second(s) 604800 = 7 days
//TBD: Change it to count by days and not seconds
$config['mod_default_ban_days'] = 604800;

//The title of the mod answer mail
$config['mod_answertitle'] = "GM ticket answer";

//Commands for ingame
$config['mod_kickcommand'] = ".kick";

$config['mod_unstuck_position_x'] = "-1829.76";
$config['mod_unstuck_position_y'] = "5362.1948";
$config['mod_unstuck_position_z'] = "-12.427672";
$config['mod_unstuck_map'] = "530";
$config['mod_unstuck_orientation'] = "2.056173";
