<?php

$config['changelog_limit'] = 10;
