<?php

$lang['email'] = "Correo";
$lang['new_password'] = "Nueva Contraseña";
$lang['token'] = "Token";
$lang['recover'] = "Recupera tu contraseña";
$lang['password_recovery'] = "Recuperacion de contraseñas";
$lang['password_reset'] = "Contraseña Reiniciada";
$lang['password_reset_success'] = "la contraseña se ha reiniciado satisfactoriamente";
$lang['password_changed'] = "contraseña cambiada";
$lang['email_sent'] = "Si su dirección de correo electrónico existe en nuestro sistema, se ha enviado un mensaje a su dirección de correo electrónico registrada. Por favor, compruebe su bandeja de entrada para continuar.";
$lang['reset_password'] = "Restablecer contraseña";
$lang['email_text'] = "Usted ha solicitado restablecer su contraseña, para completar la solicitud por favor navegue a: ";
$lang['go_back'] = "Volver Atras";
$lang['invalid'] = "token Invalido.";
$lang['error_while_inserting'] = "Error al insertar el token.";
$lang['lost_password'] = "¿Ha perdido la contraseña?";
$lang['enter_your_email'] = "Introduzca su dirección de correo electrónico y le enviaremos un enlace para restablecer su contraseña..";
