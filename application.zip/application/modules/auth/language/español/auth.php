<?php

//Login
$lang["login_label_user"] = "Usuario";
$lang["login_label_password"] = "Contraseña";
$lang["login_label_captcha"] = "Captcha";
$lang["login_label_remember"] = "Recuardame";
$lang["login_link_password_forgot"] = "¿Olvidaste tu contraseña?";
$lang["login_button"] = "Iniciar";
$lang['log_in'] = "Iniciar Sesion";

//Errors
$lang["error"] = "no se encontraron cuentas con las credenciales proporsionadas.";
$lang["ip_blocked"] = "tu IP ha sido bloqueada.";
$lang["try_again"] = "por favor intentelo nuevamente";
$lang["minutes"] = "minutos.";

//Captcha
$lang["captcha_invalid"] = "Captcha es invalido";
