<?php

$config['store_subject'] = "Item delivery!";
$config['store_body'] = "Thank you for supporting our server, here are your ordered items!";
$config['success_message'] = "Your order has been processed. You may need to log out to receive your items. In case you don't receive your order with in 5 minutes, please contact a game master.";

$config['minimize_groups_by_default'] = true;
