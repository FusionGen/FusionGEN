<?php

/**
 * Amount of players to display
 */

$config['pvp_players'] = 5;

/**
 * Realms to display
 */
$config['pvp_realms'] = array(1);
