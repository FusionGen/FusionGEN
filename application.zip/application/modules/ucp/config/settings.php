<?php

$config['show_language_chooser'] = true;
$config['avatar_upload_debug'] = false;
