<?php

$config['donation_goal_currency_sign'] = "$";
$config['donation_goal'] = 100;
