<?php

$config["bind"] = lang("bind", "wow_tooltip");
$config["slots"] = lang("slots", "wow_tooltip");
$config["damages"] = lang("damages", "wow_tooltip");
$config["spelltriggers"] = lang("spelltriggers", "wow_tooltip");
$config["armor_sub"] = lang("armor_sub", "wow_tooltip");
$config["weapon_sub"] = lang("weapon_sub", "wow_tooltip");
$config["stats"] = lang("stats", "wow_tooltip");
