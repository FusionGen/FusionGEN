<?php

    $config['horizontal_bar_height'] =  "20px";
    $config['show_uptime'] =  true;
    $config['auto_refresh_online_players'] =  true;
    $config['auto_refresh_interval_in_seconds'] = 20;
