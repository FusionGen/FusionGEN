<?php

$config['arena_teams_limit'] = 3;
$config['hk_players_limit'] = 10;
