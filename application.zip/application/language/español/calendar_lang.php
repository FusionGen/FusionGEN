<?php

$lang['cal_su']         = "Dom";
$lang['cal_mo']         = "Lun";
$lang['cal_tu']         = "Mar";
$lang['cal_we']         = "Mie";
$lang['cal_th']         = "Jue";
$lang['cal_fr']         = "Vie";
$lang['cal_sa']         = "Sab";
$lang['cal_sun']        = "Dom";
$lang['cal_mon']        = "Lun";
$lang['cal_tue']        = "Mar";
$lang['cal_wed']        = "Mie";
$lang['cal_thu']        = "Vie";
$lang['cal_fri']        = "Sab";
$lang['cal_sat']        = "Dom";
$lang['cal_sunday']     = "Domingo";
$lang['cal_monday']     = "Lunes";
$lang['cal_tuesday']    = "Martes";
$lang['cal_wednesday']  = "Miercoles";
$lang['cal_thursday']   = "Jueves";
$lang['cal_friday']     = "Viernes";
$lang['cal_saturday']   = "Sabado";
$lang['cal_jan']        = "Ene";
$lang['cal_feb']        = "Feb";
$lang['cal_mar']        = "Mar";
$lang['cal_apr']        = "Abr";
$lang['cal_may']        = "May";
$lang['cal_jun']        = "Jun";
$lang['cal_jul']        = "Jul";
$lang['cal_aug']        = "Ago";
$lang['cal_sep']        = "Sep";
$lang['cal_oct']        = "Oct";
$lang['cal_nov']        = "Nov";
$lang['cal_dec']        = "Dic";
$lang['cal_january']    = "Enero";
$lang['cal_february']   = "Febrero";
$lang['cal_march']      = "Marzo";
$lang['cal_april']      = "Abril";
$lang['cal_mayl']       = "Mayo";
$lang['cal_june']       = "Junio";
$lang['cal_july']       = "Julio";
$lang['cal_august']     = "Augosto";
$lang['cal_september']  = "Septiembre";
$lang['cal_october']    = "Octubre";
$lang['cal_november']   = "Noviembre";
$lang['cal_december']   = "Deciembre";


/* End of file calendar_lang.php */
/* Location: ./system/language/english/calendar_lang.php */
